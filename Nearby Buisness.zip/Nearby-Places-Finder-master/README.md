# Nearby Places Finder
---
### App developed using the Google Maps API and Google Places  API. The app consists on finding the nearest places around your location just by clicking on a button;moreover, this app also allows making searches with addresses and key words. This was made using Kotlin and Java programming languages on Android Studio.

#### Made by <a href = "https://github.com/RodrigoAGM">@RodrigoAGM </a> :peru:
