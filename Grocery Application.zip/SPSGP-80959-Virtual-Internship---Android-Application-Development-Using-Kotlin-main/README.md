# SPSGP-80959-Virtual-Internship---Android-Application-Development-Using-Kotlin
Virtual Internship - Android Application Development Using Kotlin

This repository contains the Project 2 (Grocery App) which was assigned as a internship project by SmartInternz Android Application Development Using Kotlin Internship

[My SmartInternz Profile](https://smartinternz.com/student-profile/feed/U0IyMDIwMDAyNjAzMA==)

[Google Developers Profile](https://g.dev/itsabhi)

[Project Demo](https://drive.google.com/file/d/1YkPR-nSosG8EVsoFNwB8DJnew7kyNaiW/view?usp=sharing)
